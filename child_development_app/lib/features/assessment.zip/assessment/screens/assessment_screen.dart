import 'package:flutter/material.dart';

import '../assessment_model.dart';
import '../services/assessment_service.dart';
import 'assessment_question_screen.dart';



class AssessmentScreen extends StatefulWidget {


  final int childId;



  const AssessmentScreen({

    super.key,

    required this.childId,

  });



  @override
  State<AssessmentScreen> createState() =>
      _AssessmentScreenState();


}







class _AssessmentScreenState
    extends State<AssessmentScreen> {



  final AssessmentService _service =
      AssessmentService();



  List<Assessment> assessments = [];



  bool loading = true;









  @override
  void initState() {

    super.initState();

    loadAssessments();

  }









  Future<void> loadAssessments() async {


    if(!mounted) return;



    setState(() {

      loading = true;

    });





    try {



      assessments =

          await _service.getChildAssessments(

            widget.childId,

          );





    }

    catch(e){



      if(mounted){


        ScaffoldMessenger.of(context)
            .showSnackBar(


          SnackBar(

            content:

                Text(

              e.toString(),

            ),


            backgroundColor:

                Colors.red,


          ),


        );


      }


    }





    if(mounted){


      setState(() {


        loading = false;


      });


    }


  }









  @override
  Widget build(BuildContext context) {



    return Scaffold(



      appBar:

          AppBar(


        title:

            const Text(

          "Assessments",

        ),



      ),







      body:


          loading



          ? const Center(


              child:

                  CircularProgressIndicator(),


            )





          : RefreshIndicator(



              onRefresh:

                  loadAssessments,





              child:


                  assessments.isEmpty



                  ? ListView(



                      children: const [



                        SizedBox(

                          height:200,

                        ),



                        Center(


                          child:

                              Text(

                            "No assessments available",

                          ),


                        ),


                      ],



                    )







                  : ListView.builder(



                      padding:

                          const EdgeInsets.all(16),




                      itemCount:

                          assessments.length,





                      itemBuilder:

                          (_, index){



                        final assessment =

                            assessments[index];







                        return Card(



                          elevation:

                              3,





                          margin:

                              const EdgeInsets.only(

                            bottom:

                                16,

                          ),





                          child:

                              Padding(



                            padding:

                                const EdgeInsets.all(18),





                            child:

                                Column(



                              crossAxisAlignment:

                                  CrossAxisAlignment.start,





                              children: [





                                Text(



                                  assessment.name,



                                  style:

                                      const TextStyle(



                                    fontSize:

                                        20,



                                    fontWeight:

                                        FontWeight.bold,



                                  ),



                                ),







                                const SizedBox(

                                  height:

                                      8,

                                ),







                                Text(

                                  assessment.description,

                                ),







                                const SizedBox(

                                  height:

                                      15,

                                ),







                                SizedBox(



                                  width:

                                      double.infinity,





                                  child:

                                      ElevatedButton.icon(



                                    icon:

                                        const Icon(

                                      Icons.play_arrow,

                                    ),





                                    label:

                                        const Text(

                                      "Start Assessment",

                                    ),





                                    onPressed: () {





                                      if(assessment.id != null){





                                        Navigator.push(



                                          context,



                                          MaterialPageRoute(



                                            builder: (_) =>

                                                AssessmentQuestionScreen(



                                              assessment:

                                                  assessment,



                                              childId:

                                                  widget.childId,



                                            ),



                                          ),



                                        );





                                      }





                                    },





                                  ),



                                ),





                              ],



                            ),



                          ),



                        );



                      },



                    ),



            ),



    );



  }


}
import 'package:flutter/material.dart';

import '../services/assessment_service.dart';


class AssessmentResultScreen extends StatefulWidget {

  final int assessmentId;
  final int childId;


  const AssessmentResultScreen({
    super.key,
    required this.assessmentId,
    required this.childId,
  });


  @override
  State<AssessmentResultScreen> createState() =>
      _AssessmentResultScreenState();

}



class _AssessmentResultScreenState
    extends State<AssessmentResultScreen> {


  final AssessmentService _service =
      AssessmentService();


  Map<String, dynamic>? result;


  bool loading = true;



  @override
  void initState() {

    super.initState();

    loadResult();

  }



  Future<void> loadResult() async {

    try {

      result = await _service.getResult(
                  widget.assessmentId,
                );


    } catch (e) {


      if (mounted) {

        ScaffoldMessenger.of(context)
            .showSnackBar(

          SnackBar(
            content:
                Text(e.toString()),
          ),

        );

      }

    }



    if (mounted) {

      setState(() {

        loading = false;

      });

    }

  }




  Color riskColor(String risk) {

    switch (risk.toUpperCase()) {

      case "LOW":
        return Colors.green;


      case "MEDIUM":
        return Colors.orange;


      case "HIGH":
        return Colors.red;


      default:
        return Colors.grey;

    }

  }





  @override
  Widget build(BuildContext context) {

    return Scaffold(

      appBar:
          AppBar(

        title:
            const Text(
          "Assessment Result",
        ),

      ),



      body:

          loading

              ? const Center(
                  child:
                      CircularProgressIndicator(),
                )


              :

              result == null

                  ? const Center(
                      child:
                          Text(
                        "No result found",
                      ),
                    )


                  :

                  Padding(

                    padding:
                        const EdgeInsets.all(20),


                    child:
                        Card(

                      elevation:
                          4,


                      child:
                          Padding(

                        padding:
                            const EdgeInsets.all(25),


                        child:
                            Column(

                          mainAxisSize:
                              MainAxisSize.min,


                          children: [


                            const Icon(

                              Icons.assessment,

                              size:
                                  70,

                              color:
                                  Colors.blue,

                            ),



                            const SizedBox(
                              height: 20,
                            ),



                            Text(

                              "Score: ${result!["score"]}/${result!["total_questions"]}",

                              style:
                                  const TextStyle(

                                fontSize:
                                    22,

                                fontWeight:
                                    FontWeight.bold,

                              ),

                            ),



                            const SizedBox(
                              height: 15,
                            ),



                            Text(

                              "${result!["percentage"]}%",

                              style:
                                  const TextStyle(

                                fontSize:
                                    35,

                                fontWeight:
                                    FontWeight.bold,

                              ),

                            ),



                            const SizedBox(
                              height: 20,
                            ),



                            Container(

                              padding:
                                  const EdgeInsets.symmetric(

                                horizontal:
                                    25,

                                vertical:
                                    12,

                              ),


                              decoration:
                                  BoxDecoration(

                                color:

                                    riskColor(
                                      result!["risk_level"],
                                    )
                                    .withValues(
                                      alpha: 0.15,
                                    ),


                                borderRadius:
                                    BorderRadius.circular(
                                      20,
                                    ),

                              ),


                              child:
                                  Text(

                                "Risk Level: ${result!["risk_level"]}",


                                style:
                                    TextStyle(

                                  fontSize:
                                      18,

                                  fontWeight:
                                      FontWeight.bold,

                                  color:
                                      riskColor(
                                        result!["risk_level"],
                                      ),

                                ),

                              ),

                            ),



                            const SizedBox(
                              height: 25,
                            ),



                            Text(

                              result!["risk_level"] ==
                                      "HIGH"

                                  ? "Consider consulting a specialist."

                                  : result!["risk_level"] ==
                                          "MEDIUM"

                                      ? "Continue monitoring development."

                                      : "Development looks good. Continue activities.",


                              textAlign:
                                  TextAlign.center,

                              style:
                                  const TextStyle(
                                fontSize:
                                    16,
                              ),

                            ),

                          ],

                        ),

                      ),

                    ),

                  ),

    );

  }

}
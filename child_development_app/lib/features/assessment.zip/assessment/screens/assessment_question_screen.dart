import 'package:flutter/material.dart';

import '../assessment_model.dart';
import '../services/assessment_service.dart';
import 'assessment_result_screen.dart';


class AssessmentQuestionScreen extends StatefulWidget {

  final Assessment assessment;
  final int childId;


  const AssessmentQuestionScreen({
    super.key,
    required this.assessment,
    required this.childId,
  });


  @override
  State<AssessmentQuestionScreen> createState() =>
      _AssessmentQuestionScreenState();

}



class _AssessmentQuestionScreenState
    extends State<AssessmentQuestionScreen> {


  final AssessmentService _service =
      AssessmentService();


  List<AssessmentQuestion> questions = [];


  Map<int, String> answers = {};

  int? sessionId;
  bool loading = true;



  @override
  void initState() {

    super.initState();

    startAssessment();

  }

Future<void> startAssessment() async {

  try {


    final result =
        await _service.startAssessment(

      childId:
          widget.childId,

      assessmentId:
          widget.assessment.id!,

    );



    sessionId =
        result["id"];



    await loadQuestions();



  } catch(e) {


    if(mounted){

      ScaffoldMessenger.of(context)
          .showSnackBar(

        SnackBar(

          content:
              Text(
            e.toString(),
          ),

        ),

      );

    }

  }

}

  Future<void> loadQuestions() async {

  try {

    if(widget.assessment.id == null){

      throw Exception(
        "Assessment ID missing",
      );

    }


    questions =
        await _service.getQuestions(
      widget.assessment.id!,
    );


  } catch(e) {

    if(mounted){

      ScaffoldMessenger.of(context)
          .showSnackBar(

        SnackBar(
          content:
              Text(
            e.toString(),
          ),
        ),

      );

    }

  }


  if(mounted){

    setState(() {

      loading = false;

    });

  }

}

  Future<void> submitAssessment() async {


    if (answers.length != questions.length) {

      ScaffoldMessenger.of(context)
          .showSnackBar(

        const SnackBar(

          content:
              Text(
            "Please answer all questions",
          ),

        ),

      );

      return;

    }



    try {


      for (var question in questions) {


        await _service.submitResponse(

          sessionId:
              sessionId!,

          questionId:
              question.id!,

          answer:
              answers[question.id]!,

        );


      }



      if (!mounted) return;



      Navigator.pushReplacement(

        context,

        MaterialPageRoute(

          builder: (_) =>
              AssessmentResultScreen(

            sessionId:
                sessionId!,

            childId:
                widget.childId,

          ),

        ),

      );



    } catch (e) {


      ScaffoldMessenger.of(context)
          .showSnackBar(

        SnackBar(

          content:
              Text(
            e.toString(),
          ),

        ),

      );


    }

  }





  @override
  Widget build(BuildContext context) {

    return Scaffold(

      appBar:
          AppBar(

        title:
            Text(
          widget.assessment.name,
        ),

      ),



      body:

          loading

              ? const Center(
                  child:
                      CircularProgressIndicator(),
                )


              :

              ListView.builder(

                padding:
                    const EdgeInsets.all(16),


                itemCount:
                    questions.length + 1,


                itemBuilder:
                    (_, index) {


                  if (index ==
                      questions.length) {


                    return SizedBox(

                      width:
                          double.infinity,


                      child:
                          ElevatedButton(

                        onPressed:
                            submitAssessment,


                        child:
                            const Text(
                          "Submit Assessment",
                        ),

                      ),

                    );

                  }



                  final question =
                      questions[index];



                  return Card(

                    margin:
                        const EdgeInsets.only(
                          bottom: 15,
                        ),


                    child:
                        Padding(

                      padding:
                          const EdgeInsets.all(16),


                      child:
                          Column(

                        crossAxisAlignment:
                            CrossAxisAlignment.start,


                        children: [


                          Text(

                            question.question,

                            style:
                                const TextStyle(

                              fontSize:
                                  17,

                              fontWeight:
                                  FontWeight.bold,

                            ),

                          ),



                          const SizedBox(
                            height: 15,
                          ),



                          Row(

                            children: [


                              Expanded(

                                child:
                                    ElevatedButton(

                                  style:
                                      ElevatedButton.styleFrom(

                                    backgroundColor:

                                        answers[question.id] ==
                                                "YES"

                                            ? Colors.green

                                            : null,

                                  ),


                                  onPressed: () {


                                    setState(() {

                                      answers[
                                          question.id!] =
                                          "YES";

                                    });


                                  },


                                  child:
                                      const Text(
                                    "YES",
                                  ),

                                ),

                              ),



                              const SizedBox(
                                width: 10,
                              ),



                              Expanded(

                                child:
                                    ElevatedButton(

                                  style:
                                      ElevatedButton.styleFrom(

                                    backgroundColor:

                                        answers[question.id] ==
                                                "NO"

                                            ? Colors.red

                                            : null,

                                  ),


                                  onPressed: () {


                                    setState(() {

                                      answers[
                                          question.id!] =
                                          "NO";

                                    });


                                  },


                                  child:
                                      const Text(
                                    "NO",
                                  ),

                                ),

                              ),


                            ],

                          ),


                        ],

                      ),

                    ),

                  );


                },

              ),

    );

  }

}
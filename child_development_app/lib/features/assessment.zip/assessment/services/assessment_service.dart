import 'package:dio/dio.dart';

import '../../../../core/api/api_service.dart';
import '../assessment_model.dart';


class AssessmentService {

  final Dio _dio = ApiService.dio;


  /// Get all assessments
  Future<List<Assessment>> getAssessments() async {

    await ApiService.setToken();

    final response = await _dio.get(
      "/assessments/",
    );


    return (response.data as List)
        .map(
          (e) => Assessment.fromJson(e),
        )
        .toList();

  }



  /// Start assessment session
  Future<Map<String, dynamic>> startAssessment({
    required int childId,
    required int assessmentId,
  }) async {
    await ApiService.setToken();

    final response = await _dio.post(
      "/assessments/start",
      data: {
        "child_id": childId,
        "assessment_id": assessmentId,
      },
    );

    return response.data;
  }


  /// Get questions for an assessment
  Future<List<AssessmentQuestion>> getQuestions(
      int assessmentId) async {

    await ApiService.setToken();


    final response = await _dio.get(
      "/assessments/$assessmentId/questions",
    );


    return (response.data as List)
        .map(
          (e) => AssessmentQuestion.fromJson(e),
        )
        .toList();

  }



  /// Get assessments for selected child

Future<List<Assessment>> getChildAssessments(

      int childId

  ) async {


    await ApiService.setToken();


    final response = await _dio.get(

      "/assessments/child/$childId",

    );


    return (response.data as List)

        .map(

          (e) => Assessment.fromJson(e),

        )

        .toList();

  }

  /// Submit answer
  Future<void> submitResponse({

  required int sessionId,

  required int questionId,

  required String answer,

}) async {


  await ApiService.setToken();



  await _dio.post(

    "/assessments/responses",

    data: {


      "session_id":
          sessionId,


      "question_id":
          questionId,


      "answer":
          answer,


    },

  );


}





  /// Complete assessment
  Future<Map<String, dynamic>> completeAssessment({
    required int sessionId,
    required int childId,
  }) async {
    await ApiService.setToken();

    final response = await _dio.post(
      "/assessments/$sessionId/complete",
      queryParameters: {
        "child_id": childId,
      },
    );

    return response.data;
  }


  /// Get assessment result
  Future<Map<String, dynamic>> getResult(int sessionId) async {
    await ApiService.setToken();

    final response = await _dio.get(
      "/assessments/$sessionId/result",
    );

    return response.data;
  }


}
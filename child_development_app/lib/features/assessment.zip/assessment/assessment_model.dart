class Assessment {
  final int? id;
  final String name;
  final String description;

  const Assessment({
    this.id,
    required this.name,
    required this.description,
  });


  factory Assessment.fromJson(
      Map<String, dynamic> json) {
    return Assessment(
      id: json["id"],
      name: json["name"] ?? "",
      description:
          json["description"] ?? "",
    );
  }


  Map<String, dynamic> toJson() {
    return {
      "name": name,
      "description": description,
    };
  }
}



class AssessmentQuestion {

  final int? id;
  final int assessmentId;
  final String question;


  const AssessmentQuestion({
    this.id,
    required this.assessmentId,
    required this.question,
  });



  factory AssessmentQuestion.fromJson(
      Map<String, dynamic> json) {

    return AssessmentQuestion(

      id: json["id"],

      assessmentId:
          json["assessment_id"],

      question:
          json["question"] ?? "",

    );
  }



  Map<String, dynamic> toJson() {

    return {

      "assessment_id":
          assessmentId,

      "question":
          question,

    };

  }

}
